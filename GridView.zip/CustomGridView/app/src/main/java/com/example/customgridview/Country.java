package com.example.customgridview;

public class Country {
    private String name;
    private String population;
    private int flag;

    public Country(String name, String population, int flag) {
        this.name = name;
        this.population = population;
        this.flag = flag;
    }

    public String getName() { return name; }
    public String getPopulation() { return population; }
    public int getFlag() { return flag; }
}
