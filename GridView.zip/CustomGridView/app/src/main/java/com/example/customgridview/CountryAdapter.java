package com.example.customgridview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;

public class CountryAdapter extends BaseAdapter {

    Context context;
    ArrayList<Country> list;

    public CountryAdapter(Context context, ArrayList<Country> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View row = convertView;
        if(row == null){
            LayoutInflater inflater = LayoutInflater.from(context);
            row = inflater.inflate(R.layout.item_country, parent, false);
        }

        ImageView imgFlag = row.findViewById(R.id.imgFlag);
        TextView txtName = row.findViewById(R.id.txtName);
        TextView txtPopulation = row.findViewById(R.id.txtPopulation);

        Country c = list.get(position);

        imgFlag.setImageResource(c.getFlag());
        txtName.setText(c.getName());
        txtPopulation.setText(c.getPopulation());

        return row;
    }
}
