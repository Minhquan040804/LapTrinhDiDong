package com.example.customgridview;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.GridView;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    GridView gridView;
    ArrayList<Country> arrayList;
    CountryAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gridView = findViewById(R.id.gridView);

        arrayList = new ArrayList<>();
        arrayList.add(new Country("Vietnam", "98000000", R.drawable.vietnam));
        arrayList.add(new Country("United States", "320000000", R.drawable.usa));
        arrayList.add(new Country("Russia", "142000000", R.drawable.russia));
        arrayList.add(new Country("Australia", "23766305", R.drawable.australia));
        arrayList.add(new Country("Japan", "126788677", R.drawable.japan));

        adapter = new CountryAdapter(this, arrayList);
        gridView.setAdapter(adapter);
    }
}
