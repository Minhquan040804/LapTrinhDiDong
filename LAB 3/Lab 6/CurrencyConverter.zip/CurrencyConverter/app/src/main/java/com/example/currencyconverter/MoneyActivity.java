package com.example.currencyconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MoneyActivity extends AppCompatActivity {

    EditText txtNumber;
    Spinner spnUnits;
    TextView[] lblResults;

    // Danh sách mã tiền
    String[] units = {"USD","EUR","GBP","INR","AUD","CAD","ZAR","NZD","JPY","VND"};

    // Ma trận tỉ giá
    double[][] ratio = {
            {1.000000, 0.8918, 0.64070, 63.3318, 1.21288, 1.16236, 11.7129, 1.29310, 118.337, 21385.7},
            {1.24172, 1.00000, 0.7575, 76.6084, 1.51266, 1.44314, 13.5471, 1.6576, 146.927, 26651.8},
            {1.56044, 1.2567, 1.00000, 98.7844, 1.90841, 1.8355, 18.263, 2.0179, 184.638, 33374.9},
            {0.0158, 0.0130, 0.01012, 1.00000, 0.01936, 0.01849, 0.20243, 0.02169, 1.86918, 337.811},
            {0.8245, 0.6606, 0.5233, 52.5808, 1.00000, 0.9591, 9.6114, 1.0618, 91.1125, 1756.97},
            {0.8600, 0.6928, 0.5495, 54.8585, 1.0430, 1.00000, 10.0000, 1.1057, 95.1077, 18401.7},
            {0.0854, 0.0692, 0.0548, 5.4083, 0.1040, 0.1000, 1.00000, 0.11057, 9.5100, 1840.17},
            {0.7732, 0.6270, 0.4973, 49.6240, 0.9412, 0.9050, 9.0583, 1.00000, 86.5973, 16552.1},
            {0.0085, 0.0068, 0.0054, 0.5473, 0.0109, 0.0105, 0.1049, 0.0115, 1.00000, 194.92},
            {0.000052, 0.000040, 0.00003, 0.00296, 0.00057, 0.00054, 0.0054, 0.00060, 0.0051, 1.00000}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_money);

        txtNumber = findViewById(R.id.txtNumber);
        spnUnits = findViewById(R.id.spnUnit);

        lblResults = new TextView[]{
                findViewById(R.id.lblUsd),
                findViewById(R.id.lblEur),
                findViewById(R.id.lblGbp),
                findViewById(R.id.lblInr),
                findViewById(R.id.lblAud),
                findViewById(R.id.lblCad),
                findViewById(R.id.lblZar),
                findViewById(R.id.lblNzd),
                findViewById(R.id.lblJpy),
                findViewById(R.id.lblVnd)
        };

        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, units);
        adapter.setDropDownViewResource(android.R.layout.simple_list_item_1);
        spnUnits.setAdapter(adapter);

        // Khi chọn đơn vị
        spnUnits.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                changeMoneyUnit();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        // Khi nhập số
        txtNumber.addTextChangedListener(new TextWatcher() {
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                changeMoneyUnit();
            }
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}
        });
    }

    private void changeMoneyUnit() {
        int idx = spnUnits.getSelectedItemPosition();
        if (idx < 0) idx = 0;

        String input = txtNumber.getText().toString();
        if (input.isEmpty()) input = "0";

        double number = Double.parseDouble(input);

        // Tính tất cả loại tiền
        for (int i = 0; i < lblResults.length; i++) {
            double result = number * ratio[idx][i];
            lblResults[i].setText(String.valueOf(result));
        }
    }
}