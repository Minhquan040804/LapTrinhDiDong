package com.example.lengthconverter;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.*;

public class MainActivity extends AppCompatActivity {

    // Danh sách đơn vị
    private String[] units = {
            "Hải lý", "Dặm", "Km", "Lý", "Mét", "Yard", "Foot", "Inch"
    };

    // Ma trận tỉ lệ
    private double[][] ratio = {
            {1, 0.5399568, 1.852, 20.2537, 1852, 2025.3718, 6076.12, 72913.3853},
            {1.852, 1, 1.60934, 17.6000003, 1609.34, 1760, 5280, 63360},
            {0.53996, 0.62137, 1, 10.970, 1000, 1093.61, 3280.84, 39370.1},
            {0.04934, 0.05681, 0.09092, 1, 91.44, 100, 300, 3600},
            {0.00054, 0.00062, 0.001, 0.0109, 1, 1.0936, 3.28084, 39.37},
            {0.00049, 0.00057, 0.00091, 0.0100, 0.9144, 1, 3, 36},
            {0.00016, 0.00019, 0.00030, 0.0033, 0.3048, 0.3333, 1, 12},
            {0.0000137, 0.000016, 0.000025, 0.00028, 0.0254, 0.0277, 0.0833, 1}
    };

    // View
    private EditText txtNumber;
    private Spinner spnUnits;
    private TextView[] lblResults;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtNumber = findViewById(R.id.txtNumber);
        spnUnits = findViewById(R.id.spnUnits);

        lblResults = new TextView[]{
                findViewById(R.id.lblHaiLy),
                findViewById(R.id.lblDam),
                findViewById(R.id.lblKm),
                findViewById(R.id.lblLy),
                findViewById(R.id.lblMet),
                findViewById(R.id.lblYard),
                findViewById(R.id.lblFoot),
                findViewById(R.id.lblInch)
        };

        // Gán dữ liệu vào Spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, units
        );
        adapter.setDropDownViewResource(android.R.layout.simple_list_item_1);
        spnUnits.setAdapter(adapter);

        // Sự kiện đổi lựa chọn
        spnUnits.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                convert();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        // Sự kiện thay đổi số nhập
        txtNumber.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                convert();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }


    private void convert() {
        int row = spnUnits.getSelectedItemPosition();
        String input = txtNumber.getText().toString();
        if (input.isEmpty()) input = "0";

        double number = Double.parseDouble(input);

        for (int i = 0; i < lblResults.length; i++) {
            double value = number * ratio[row][i];
            lblResults[i].setText(String.valueOf(value));
        }
    }
}
