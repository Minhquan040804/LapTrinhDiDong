package com.example.customgridview;

public class Contributor {
    private String name;
    private String score;
    private int avatar;

    public Contributor(String name, String score, int avatar) {
        this.name = name;
        this.score = score;
        this.avatar = avatar;
    }

    public String getName() { return name; }
    public String getScore() { return score; }
    public int getAvatar() { return avatar; }
}
