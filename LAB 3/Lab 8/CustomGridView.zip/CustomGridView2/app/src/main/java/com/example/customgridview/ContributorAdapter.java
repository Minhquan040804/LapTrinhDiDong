package com.example.customgridview;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;

public class ContributorAdapter extends BaseAdapter {

    Context context;
    ArrayList<Contributor> list;

    public ContributorAdapter(Context context, ArrayList<Contributor> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int i) {
        return list.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;

        if (row == null) {
            row = LayoutInflater.from(context)
                    .inflate(R.layout.item_contributor, parent, false);
        }

        ImageView imgAvatar = row.findViewById(R.id.imgAvatar);
        TextView txtName = row.findViewById(R.id.txtName);
        TextView txtScore = row.findViewById(R.id.txtScore);

        Contributor c = list.get(position);

        imgAvatar.setImageResource(c.getAvatar());
        txtName.setText(c.getName());
        txtScore.setText(c.getScore());

        return row;
    }
}
