package com.example.customgridview;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.GridView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    GridView grid;
    ArrayList<Contributor> array;
    ContributorAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        grid = findViewById(R.id.gridContributors);
        array = new ArrayList<>();

        array.add(new Contributor("Maboo", "283,297", R.drawable.avatar));
        array.add(new Contributor("SameOldShawn", "252,433", R.drawable.avatar));
        array.add(new Contributor("Magnitude901", "164,935", R.drawable.avatar));
        array.add(new Contributor("Brandon", "100,466", R.drawable.avatar));
        array.add(new Contributor("Clement_RGF", "93,932", R.drawable.avatar));
        array.add(new Contributor("Nebja", "84,187", R.drawable.avatar));
        array.add(new Contributor("BBDS", "81,762", R.drawable.avatar));
        array.add(new Contributor("PleaseDe-ModMe", "79,243", R.drawable.avatar));
        array.add(new Contributor("DLizzle", "76,331", R.drawable.avatar));
        array.add(new Contributor("palacelight", "75,497", R.drawable.avatar));
        array.add(new Contributor("TheDarkKnight", "69,138", R.drawable.avatar));
        array.add(new Contributor("hellrel", "68,903", R.drawable.avatar));

        adapter = new ContributorAdapter(this, array);
        grid.setAdapter(adapter);
    }
}
