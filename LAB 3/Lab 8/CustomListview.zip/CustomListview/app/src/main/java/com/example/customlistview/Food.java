package com.example.customlistview;

public class Food {
    public int image;
    public String name;
    public String desc;
    public String price;

    public Food(int image, String name, String desc, String price) {
        this.image = image;
        this.name = name;
        this.desc = desc;
        this.price = price;
    }
}
