package com.example.customlistview;

import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class FoodAdapter extends BaseAdapter {

    ArrayList<Food> list;

    public FoodAdapter(ArrayList<Food> list) {
        this.list = list;
    }

    @Override
    public int getCount() { return list.size(); }

    @Override
    public Object getItem(int position) { return list.get(position); }

    @Override
    public long getItemId(int position) { return 0; }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View view = View.inflate(parent.getContext(), R.layout.row_food, null);

        Food f = list.get(position);

        ImageView img = view.findViewById(R.id.imgFood);
        img.setImageResource(f.image);

        TextView txtName = view.findViewById(R.id.txtName);
        txtName.setText(f.name);

        TextView txtDesc = view.findViewById(R.id.txtDesc);
        txtDesc.setText(f.desc);

        TextView txtPrice = view.findViewById(R.id.txtPrice);
        txtPrice.setText(f.price);

        return view;
    }
}