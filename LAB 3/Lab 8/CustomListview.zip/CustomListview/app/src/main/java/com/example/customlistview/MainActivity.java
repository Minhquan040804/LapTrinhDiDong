package com.example.customlistview;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView lvFood;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lvFood = findViewById(R.id.lvFood);

        ArrayList<Food> list = new ArrayList<>();

        list.add(new Food(R.drawable.hamburger, "Hamburger", "Bánh mì kẹp thịt trộn", "Giá:12.000đ"));
        list.add(new Food(R.drawable.banhmi, "Bánh mì", "Bánh mì kẹp thịt", "Giá:10.000đ"));
        list.add(new Food(R.drawable.banhbao, "Bánh bao", "Bánh bao nhân thịt, trứng", "Giá:8.000đ"));
        list.add(new Food(R.drawable.banhgio, "Bánh giò", "Bánh lá dùng cho bữa xế", "Giá:6.000đ"));
        list.add(new Food(R.drawable.banhchay, "Bánh giò chay", "Bánh giò chay bằng nếp hoặc lạt", "Giá:5.000đ"));
        list.add(new Food(R.drawable.banhgonhanthit, "Bánh gò nhân thịt", "Bánh gò nhân thịt ngon", "Giá:8.000đ"));

        FoodAdapter adapter = new FoodAdapter(list);
        lvFood.setAdapter(adapter);
    }
}