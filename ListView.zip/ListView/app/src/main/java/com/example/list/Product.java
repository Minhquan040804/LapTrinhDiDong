package com.example.list;

public class Product {
    public int image;
    public String title;
    public String content;

    public Product(int image, String title, String content) {
        this.image = image;
        this.title = title;
        this.content = content;
    }
}
